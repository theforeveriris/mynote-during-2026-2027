public class Test2 {
    public static void main(String[] args) {
        //单分支
        int score = 70;
        if(score>=60){
            System.out.println("及格");
        }

        //双分支
        int age = 17;
        if(age>=18){
            System.out.println("成年");
        }else{
            System.out.println("未成年");
        }

        //多分支
        int score2 = 85;
        if(score2>=90){
            System.out.println("优秀");
        }else if(score>=80){
            System.out.println("良好");
        }else if(score>=70){
            System.out.println("中等");
        }else if(score>=60){
            System.out.println("及格");
        }else{
            System.out.println("不及格");
        }

        //switch
        //status会自上而下匹配，一旦匹配到会停止匹配
        int status = 2;
        switch(status){
            case 1:
                System.out.println("待支付");
                break;
            case 2:
                System.out.println("已支付");
                break;
            case 3:
                System.out.println("已发货");
                break;
            default:
                System.out.println("无效状态");
                break;
        }
        // 后续代码
    }
}
