import java.util.Scanner;

public class Test5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //系统默认密码
        int password = 123456;

        for(int i=1; i<=3; i++){
            //提示语
            System.out.println("请输入密码：");
            int pwd = scanner.nextInt();
            if(password != pwd){
                int left = 3 - i;
                if(left == 0){
                    System.out.println("密码错误3次，账户锁定");
                }else{
                    System.out.println("密码错误，还剩" + left + "次机会");
                }
                continue;
            }
            System.out.println("密码正确，欢迎进入系统");
            break;//终止循环
        }
    }
}
