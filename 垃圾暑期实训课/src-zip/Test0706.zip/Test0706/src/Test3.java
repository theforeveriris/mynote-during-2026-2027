public class Test3 {
    public static void main(String[] args) {
        //for
        for(int i=1;i<=5;i++){
            System.out.println("第" + i + "条数据");//第1 2 3 4 5条数据
        }

        //while--游标
        //模拟游标读取数据，直到无记录
        int count = 1;
        while(count <= 3){
            System.out.println("读取第" + count + "行");//
            count++;//手动自增，避免无限循环
        }

        //break -- 跳出当前层整个循环
        int j=1;
        for(;j<=10;j++){
            if(j==5){
                System.out.println("终止整个本层循环");
                break;
            }
            System.out.println("j=" + j);//1 2 3 4
        }

        //continue -- 跳出当前层本次循环，继续下一次循环
        int k=1;
        for(;k<=10;k++){
            if(k==5){
                System.out.println("终止本层循环的本次循环，后续循环继续");
                continue;
            }
            System.out.println("k=" + k);//
        }
    }
}
