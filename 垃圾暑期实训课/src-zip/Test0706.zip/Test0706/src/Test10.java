import java.util.ArrayList;

public class Test10 {
    public static void main(String[] args) {
        //创建存储字符串的ArrayList集合
        ArrayList<String> list = new ArrayList<>();

        //添加元素
        list.add("张三");
        list.add("王五");
        list.add("王五");
        list.add("赵六");
        list.add("孙七");

        //获取长度
        System.out.println("集合的长度:" + list.size());

        //获取某个元素
        System.out.println("获取索引为2的元素:" + list.get(2));

        //修改元素
        list.set(1, "李四四");

        //删除元素
        list.remove(3);

        //遍历
        for (int i = 0; i < list.size(); i++) {
            System.out.println("list[" + i + "] = " + list.get(i));
        }
        System.out.println("***************************");
        //增强遍历
        for(String element : list){
            System.out.println("element = " + element);
        }
    }
}
