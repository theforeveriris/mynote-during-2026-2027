public class Test8 {
    public static void main(String[] args) {
        int[] arr = {12,45,7,89,23};
        int sum = 0;
        int max = arr[0];//假设第一个元素为最大值

        for (int i = 0; i < arr.length; i++){
            sum += arr[i];//累加求和
            if (arr[i] > max){
                max = arr[i];//更新最大值
            }
        }

        System.out.println("数组总和:" + sum);//176
        System.out.println("数组的最大值:" + max);
    }
}
