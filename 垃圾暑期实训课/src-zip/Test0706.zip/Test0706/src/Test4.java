import java.util.Scanner;

public class Test4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //提示语
        System.out.println("请输入一个整数：");
        int n = scanner.nextInt();

        for(int i=1; i<=n; i++){
            if(i%2 == 0){
                continue;
            }
            if(i == 1){
                System.out.println(i +"是奇数，不是素数");
                continue;
            }

            //判断素数
            boolean isPrime = true;//默认是素数
            for(int j=2; j<i; j++){
                if(i%j == 0){
                    isPrime = false;
                    break;
                }
            }

            if(isPrime){
                System.out.println(i +"是奇数，也是素数");
            }else{
                System.out.println(i +"是奇数，但不是素数");
            }
        }
    }
}
