public class Test7 {
    public static void main(String[] args) {
        //写法1 先声明，再分配长度
        int[] arr1;
        arr1 = new int[3];//长度3，默认值都为0

        //赋值
        arr1[0] = 10;
        arr1[1] = 20;
        arr1[2] = 30;

        //写法2 申明同时指定长度
        double[] arr2 = new double[2];
        arr2[0] = 1.1;
        arr2[1] = 2.2;

        //写法3 声明+直接赋值
        String[] arr3 = {"张三", "李四", "王五"};

        //获取长度
        System.out.println("arr1的长度是：" + arr1.length);//3

        // 获取数组每个元素的值
        for(int i=0; i<arr1.length; i++){
            System.out.println("arr1[" + i + "] = " + arr1[i]);//arr1[0] = 10 arr1[1] = 20 arr1[2] = 30
        }

        //增强for循环
        for (double element : arr2){
            System.out.println("姓名 = " + element);//姓名 = 1.1 姓名 = 2.2
        }
    }
}
