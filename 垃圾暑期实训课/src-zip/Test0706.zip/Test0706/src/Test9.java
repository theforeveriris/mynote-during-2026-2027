import java.util.Scanner;

public class Test9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] arr = {5,11,33,77,99};

        System.out.println("请输入要查找的数字:");
        int target = scanner.nextInt();
        int index = -1;//默认-1

        for(int i=0; i<arr.length; i++){
            if(arr[i] == target){
                index = i;
                break;
            }
        }
        System.out.println("目标元素的下标:" + index);
    }
}
