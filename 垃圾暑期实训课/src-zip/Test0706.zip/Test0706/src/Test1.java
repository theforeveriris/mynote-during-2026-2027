public class Test1 {
    public static void main(String[] args){
        //变量  数据类型 变量名 = 变量值
        int id = 1001;
        String name = "jack";
        double score = 95.5;
        boolean isOk = true;

        //赋值运算符 =
        int i = 10;
        double pi = 3.14;

        //算术运算符 + - * / % ++  --
        int  a = 10;
        int b = 3;
        System.out.println(a + " + " + b + "=" + (a+b));//13
        System.out.println(a + " - " + b + "=" + (a-b));//7
        System.out.println(a + " * " + b + "=" + (a*b));//30
        System.out.println(a + " / " + b + "=" + (a/b));//3
        System.out.println(a + " % " + b + "=" + (a%b));//1

        a++;
        System.out.println("a=" + a);//11
        int c = a++;//当a++参与运算，先赋值，后自增
        System.out.println("c=" + c);//11
        System.out.println("a=" + a);//12

        int d = ++a;//当++a参与运算，先自增，后赋值
        System.out.println("d=" + d);//13
        System.out.println("a=" + a);//13

        //比较运算符---结果是boolean
        int num1 = 20;
        int num2 = 10;
        boolean result1 = num1>num2;
        boolean result2 = num1<num2;
        System.out.println(num1 + " > " + num2 + "=" + result1);//true
        System.out.println(num1 + " < " + num2 + "=" + result2);//false

        //逻辑运算符  && || ！
        //&&  当参与运算的每个元素都是true，结果才为true，否则为false
        //|| 当参与运算的每个元素至少有一个true，结果为true，否则为false
        //！ 取反
        boolean result3 = (num1>5)&&(num2<15);
        boolean result4 = (num1>5)||(num2<15);
        boolean result5 = !(num1>5);
        System.out.println(result3);//true
        System.out.println(result4);//true
        System.out.println(result5);//false

        double mathScore = 88.5;
        double englishScore = 95.0;

        double avgScore = (mathScore + englishScore) / 2;
        System.out.println("avgScore=" + avgScore);//avgScore=91.75

        boolean isQualified = avgScore >= 60;
        System.out.println("isQualified=" + isQualified);//

    }
}
