import java.util.Scanner;

public class Test6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while(true){
            System.out.println("输入年份(当输入0退出)：");
            int year = scanner.nextInt();
            if(year == 0){
                System.out.println("退出程序");
                break;
            }

            System.out.println("请输入月份:");
            int month = scanner.nextInt();
            int day = 0;
            switch(month){
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    day = 31;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    day=30;
                    break;
                case 2:
                    //闰年判断：能被4整除但不能被100整除，或者能被400整除
                    if(year % 4 == 0 && year % 100 != 0 || year % 400 == 0){
                        day = 29;
                    }else{
                        day = 28;
                    }
                    break;
            }
            System.out.println(year + "年" + month + "月有" + day + "天");
        }
    }
}
