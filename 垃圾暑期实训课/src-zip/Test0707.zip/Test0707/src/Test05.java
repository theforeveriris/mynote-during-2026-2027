import java.util.HashMap;
import java.util.HashSet;

public class Test05 {
    public static void main(String[] args) {
        //创建HashMap
        HashMap<Integer, String> map = new HashMap<>();

        //添加
        map.put(1001,"张三");
        map.put(1002,"李四");
        map.put(1003,"王五");
        map.put(1001,"赵六");//重复的key，value覆盖
        map.put(1004,"张三");

        //根据key获取value
        System.out.println(map.get(1001));

        //删除键值对
        map.remove(1002);

        //判断key是否存在
        System.out.println(map.containsKey(1003));

        //遍历所有的value
        for (String value : map.values()) {
            System.out.println(value);
        }
    }
}
