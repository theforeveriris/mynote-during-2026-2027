public class Test10 {
    public static void main(String[] args) {
        Pet pet = new Pet();
        pet.setName("小黑");
        pet.setWeight(5.5);
        System.out.println(pet.getName() + "的重量是" + pet.getWeight());
    }
}
