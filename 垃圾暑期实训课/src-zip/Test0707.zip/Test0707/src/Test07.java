public class Test07 {
    public static void main(String[] args) {
        //创建学生对象1
        Student stu1 = new Student();//无参构造方法1111111111111111111

        //创建学生对象2
        Student stu2 = new Student();//无参构造方法1111111111111111111

        //调用有参构造方法
        Student stu3 = new Student("002", 19, "李四", "12345678902");//有参构造方法2222222222222222222

        //通过分析内存地址不一致，说明创建了两个不同的对象
        System.out.println("stu1:" + stu1);//stu1:Student@4554617c
        System.out.println("stu2:" + stu2);//stu2:Student@74a14482

        //给属性赋值  对象名.属性名 = 值
        stu1.no = "001";
        stu1.age = 18;
        stu1.name = "张三";
        stu1.tel = "12345678901";

        //调用对象的方法  对象名.方法名
        stu1.study();//张三正在学习，今年18岁
        stu1.play();//张三正在玩耍

        stu2.study();//null正在学习，今年0岁
        stu2.play();//null正在玩耍
    }
}
