
//学生类
public class Student {
    //静态---属性
    String no;//学号

    int age;//年龄
    String name;//姓名
    String tel;//手机号

    //动态--行为
    public Student(){
        System.out.println("无参构造方法1111111111111111111");
    }

    //有参构造方法
    public Student(String no, int age, String name, String tel) {
        this.no = no;
        this.age = age;
        this.name = name;
        this.tel = tel;
        System.out.println("有参构造方法2222222222222222222");
    }
    public void study() {
        System.out.println(name + "正在学习，今年" + age + "岁");
    }
    public void play(){
        System.out.println(name + "正在玩耍");
    }
}
