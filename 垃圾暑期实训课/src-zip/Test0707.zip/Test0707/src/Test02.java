import java.util.LinkedList;

public class Test02 {
    public static void main(String[] args) {
        //创建LinkedList---双向链表
        LinkedList<Integer> link = new LinkedList<>();

        //添加元素
        link.add(10);
        link.add(20);

        //头部
        link.addFirst(5);

        //尾部
        link.addLast(30);

        //输出
        System.out.println(link);//[5, 10, 20, 30]

        //获取首元素
        System.out.println("首元素:" + link.getFirst());//5

        //获取尾元素
        System.out.println("尾元素:" + link.getLast());//30
    }
}
