public class Person {
    //属性私有化
    private String name;//姓名
    private int age;//年龄

    //提供公共的接口，获取属性的值
    public String getName() {
        return name;
    }

    // 提供公共的接口，设置属性的值
    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        //添加合理性判断
        if (age < 0 || age > 120) {
            System.out.println("年龄设置不合理,系统默认年龄为0");
            this.age = 0;
        }else{
            this.age = age;
        }
    }
}