public class Test08 {
    public static void main(String[] args) {
        //创建手机对象1
        Phone phone1 = new Phone();
        phone1.brand = "华为";
        phone1.price = 3000;

        System.out.println(phone1.brand);
        System.out.println(phone1.price);

        phone1.call("12345678901");
        phone1.sendSMS("12345678901", "hello");

        //创建手机对象2
        Phone phone2 = new Phone();
        phone2.brand = "小米";
        phone2.price = 2000;

        System.out.println(phone2.brand);
        System.out.println(phone2.price);

        phone2.call("12345678901");
        phone2.sendSMS("12345678901", "hello");
    }
}
