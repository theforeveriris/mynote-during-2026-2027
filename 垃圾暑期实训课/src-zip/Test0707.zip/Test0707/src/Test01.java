import java.util.ArrayList;
import java.util.List;

public class Test01 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();

        // 添加元素
        list.add("张三");
        list.add("李四");
        list.add("王五五");
        list.add("赵六六");

        //倒叙删除，防止下标错乱，从后往前删除
        for (int i = list.size() - 1; i >= 0; i--) {
            String name = list.get(i);

            //判断名字长度小于3则删除
            if (name.length() < 3) {
                list.remove(i);
            }
        }

        //过滤后的集合
        System.out.println("过滤后:" + list);
    }
}
