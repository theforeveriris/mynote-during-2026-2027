public class Test09 {
    public static void main(String[] args) {
        Person p = new Person();

        //p.age = -20;//给对象p的属性年龄赋值
        //p.name = "张三";
        p.setName("张三");
        p.setAge(-20);

        System.out.println(p.getName() + "的年龄:" + p.getAge());
    }
}

