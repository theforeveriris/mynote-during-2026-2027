import java.util.HashSet;

public class Test03 {
    public static void main(String[] args) {
        //创建HashSet对象
        HashSet<String> set = new HashSet<>();

        //添加元素
        set.add("苹果");
        set.add("香蕉");
        set.add("橘子");
        set.add("苹果");//添加重复元素自动过滤

        //增强for循环遍历
        for (String fruit : set) {
            System.out.println(fruit);//苹果 香蕉 橙子  顺序可能不同
        }
    }
}
