public class Phone {
    //属性
    String brand;
    double price;

    //方法
    //打电话
    public void call(String number) {
        System.out.println(brand + "的手机,价格:" + price + "元，正在拨打:" + number);
    }

    //发短信
    public void sendSMS(String number, String content) {
        System.out.println(brand + "的手机,价格:" + price + "元，正在给" + number + "发送短信:" + content);
    }
}
