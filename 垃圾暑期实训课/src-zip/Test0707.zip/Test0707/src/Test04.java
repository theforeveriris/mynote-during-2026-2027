import java.util.HashSet;

public class Test04 {
    public static void main(String[] args) {
        int[] arr = {10,20,10,30,20,40};

        //创建HashSet对象
        HashSet<Integer> set = new HashSet<>();

        //增强便利数组存入set，自动过滤重复元素
        for (int num : arr) {
            set.add(num);//自动过滤重复元素
        }

        //过滤后的元素
        System.out.println("过滤后数据:" + set);//[10, 20, 30, 40]
    }
}
