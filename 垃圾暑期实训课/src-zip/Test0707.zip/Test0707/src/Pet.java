//宠物类
public class Pet {
    //属性
    private String name;
    private double weight;

    //方法
    //get
    public String getName() {
        return name;
    }
    public double getWeight() {
        return weight;
    }
    //set
    public void setName(String name) {
        this.name = name;
    }
    public void setWeight(double weight) {
        //合理性判断
        if (weight < 0) {
            System.out.println("重量设置不合理,系统默认重量为0");
            this.weight = 0;
        }else{
            this.weight = weight;
        }
    }
}
