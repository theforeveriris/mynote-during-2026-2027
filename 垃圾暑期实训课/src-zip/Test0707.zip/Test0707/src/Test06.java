import java.util.HashMap;

public class Test06 {
    public static void main(String[] args) {
        String str = "aabbcccdddd";

        //HashMap
        HashMap<Character, Integer> countMap = new HashMap<>();

        //遍历字符串每个字符
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);

            //判断map是否已有该字符
            if (countMap.containsKey(c)) {
                //获取该字符的value
                Integer value = countMap.get(c);
                //value加1
                value++;
                //put方法put(c,value)会覆盖之前的value
                countMap.put(c, value);
            } else {
                //put方法put(c,1)会覆盖之前的key
                countMap.put(c, 1);
            }
        }
        System.out.println("字符统计:" + countMap);
    }
}
